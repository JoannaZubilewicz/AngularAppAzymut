import { Component, OnInit } from '@angular/core';
import { WeatherapiService } from './weatherapi.service';
import { appInitializerFactory } from '@angular/platform-browser/src/browser/server-transition';

@Component({
  selector: 'app-pogoda',
  templateUrl: './pogoda.component.html',
  styleUrls: ['./pogoda.component.scss']
})
export class PogodaComponent implements OnInit {
  value = '';
  temp = 0;
  description= '';
  lon= 0;
  lat= 0;
  constructor(private api:WeatherapiService) { }

  ngOnInit() {
  }

  onClick(){
    this.api.getCityWeather(this.value).subscribe(
      data=>{
        this.temp = data.main.temp;
        this.description = data.weather.description;
        this.lon=data.coord.lon;
        this.lat=data.coord.lat;
      }
      );
  }

 
}
