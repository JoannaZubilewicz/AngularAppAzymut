import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PogodaComponent } from './pogoda.component';

@Injectable({
  providedIn: 'root'
})
export class WeatherapiService {

  constructor(private http: HttpClient) { }

  

  public getCityWeather(city){
    return this.http.get<Weather>('https://api.openweathermap.org/data/2.5/weather?q='+city+
    '&APPID=ceb94dd3597362a41da61449bb1303ca&units=metric');
  }
}


export interface Weather{
  main: Temp;
  coord: Coord;
  weather: Pogoda;
}
export interface Pogoda{
  main: string;
  description: string;
}
export interface Coord {
  lon: number;
  lat: number;
}
export interface Temp{
  temp: number;
  pressure: number;
  humidity: number;
  temp_min: number;
  temp_max: number;
}