import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-szkolenia',
  templateUrl: './szkolenia.component.html',
  styleUrls: ['./szkolenia.component.scss']
})
export class SzkoleniaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
