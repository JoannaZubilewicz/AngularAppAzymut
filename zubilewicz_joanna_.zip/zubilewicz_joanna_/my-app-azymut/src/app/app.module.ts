import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatCheckboxModule} from '@angular/material';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatRadioModule} from '@angular/material/radio';
import {MatMenuModule} from '@angular/material/menu';
import {MatToolbarModule} from '@angular/material/toolbar'; 
import {MatIconModule} from '@angular/material/icon';
import { MainSliderComponent } from './main-slider/main-slider.component';
import { WelcomePageComponent } from './welcome-page/welcome-page.component';
import { KolonieZimowiskaComponent } from './kolonie-zimowiska/kolonie-zimowiska.component';

import { SzkoleniaComponent } from './szkolenia/szkolenia.component';
import { GaleriaComponent } from './galeria/galeria.component';
import { KontaktComponent } from './kontakt/kontakt.component';
import {MatButtonModule} from '@angular/material/button'; 
import {SlideshowModule} from 'ng-simple-slideshow';
import { PogodaComponent } from './pogoda/pogoda.component';
import { HttpClientModule } from '@angular/common/http';
import {MatInputModule} from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { KolLetnieComponent } from './kol-letnie/kol-letnie.component';

@NgModule({
  declarations: [
    AppComponent,
    MainSliderComponent,
    WelcomePageComponent,
    KolonieZimowiskaComponent,
    KolLetnieComponent,
    SzkoleniaComponent,
    GaleriaComponent,
    KontaktComponent,
    PogodaComponent
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatMenuModule,
    MatToolbarModule,
    MatIconModule,
    SlideshowModule,
    HttpClientModule,
    MatInputModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
