import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kolonie-zimowiska',
  templateUrl: './kolonie-zimowiska.component.html',
  styleUrls: ['./kolonie-zimowiska.component.scss']
})
export class KolonieZimowiskaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
