import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KolonieZimowiskaComponent } from './kolonie-zimowiska.component';

describe('KolonieZimowiskaComponent', () => {
  let component: KolonieZimowiskaComponent;
  let fixture: ComponentFixture<KolonieZimowiskaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KolonieZimowiskaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KolonieZimowiskaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
