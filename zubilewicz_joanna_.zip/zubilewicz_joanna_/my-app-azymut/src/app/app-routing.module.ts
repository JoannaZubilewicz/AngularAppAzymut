import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomePageComponent } from './welcome-page/welcome-page.component';
import { MainSliderComponent } from './main-slider/main-slider.component';
import { KolonieZimowiskaComponent } from './kolonie-zimowiska/kolonie-zimowiska.component';
import { SzkoleniaComponent } from './szkolenia/szkolenia.component';
import { GaleriaComponent } from './galeria/galeria.component';
import { KontaktComponent } from './kontakt/kontakt.component';
import { PogodaComponent } from './pogoda/pogoda.component';
import { KolLetnieComponent} from './kol-letnie/kol-letnie.component';


const routes: Routes = [
  {path:'',component: WelcomePageComponent},
  {path:'home', component: MainSliderComponent},
  {path:'kol-letnie', component: KolLetnieComponent},
  {path:'kolonie-zimowiska',component:KolonieZimowiskaComponent},
  {path:'szkolenia',component:SzkoleniaComponent},
  {path:'galeria',component:GaleriaComponent},
  {path:'pogoda',component:PogodaComponent},
  {path:'kontakt',component:KontaktComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
