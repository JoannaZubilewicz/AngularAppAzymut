import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-main-slider',
  templateUrl: './main-slider.component.html',
  styleUrls: ['./main-slider.component.scss']
})
export class MainSliderComponent implements OnInit {
  // imageUrlArray: string[];

  imageUrls: string[] = [
    'assets/img/img-1.png',
    'assets/img/img-2.jpg',
    'assets/img/img-3.jpg'
  ];
  backgroundPadding: string = '200px 10px';
  height: string = '500px';
  minHeight: string = '20px';
  arrowSize: string = '40px';
  showArrows: boolean = true;
  disableSwiping: boolean = false;
  autoPlay: boolean = true;
  autoPlayInterval: number = 3333;
  stopAutoPlayOnSlide: boolean = true;
  debug: boolean = false;
  backgroundSize: string = 'cover';
  backgroundPosition: string = 'center center';
  backgroundRepeat: string = 'no-repeat';
  showDots: boolean = true;
  dotColor: string = '#FFF';
  showCaptions: boolean = true;
  captionColor: string = '#FFF';
  captionBackground: string = 'rgba(0, 0, 0, .35)';
  lazyLoad: boolean = false;
  hideOnNoSlides: boolean = false;
  width: string = '900px';
  fullscreen: boolean = false;
  enableZoom: boolean = false;
  enablePan: boolean = false;
 


  constructor() { 
  
  }

  ngOnInit() {
   
  }



}


