import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kol-letnie',
  templateUrl: './kol-letnie.component.html',
  styleUrls: ['./kol-letnie.component.scss']
})
export class KolLetnieComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
