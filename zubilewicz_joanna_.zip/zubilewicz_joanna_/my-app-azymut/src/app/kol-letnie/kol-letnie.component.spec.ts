import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KolLetnieComponent } from './kol-letnie.component';

describe('KolLetnieComponent', () => {
  let component: KolLetnieComponent;
  let fixture: ComponentFixture<KolLetnieComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KolLetnieComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KolLetnieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
